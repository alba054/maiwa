<?php

namespace App\Http\Controllers;

use App\Models\Perlakuan;
use Illuminate\Http\Request;

class PerlakuanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Perlakuan  $perlakuan
     * @return \Illuminate\Http\Response
     */
    public function show(Perlakuan $perlakuan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Perlakuan  $perlakuan
     * @return \Illuminate\Http\Response
     */
    public function edit(Perlakuan $perlakuan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Perlakuan  $perlakuan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Perlakuan $perlakuan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Perlakuan  $perlakuan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Perlakuan $perlakuan)
    {
        //
    }
}
