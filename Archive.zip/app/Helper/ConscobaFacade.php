<?php

namespace App\Helper;

class ConstcobaFacade{
    protected static function getFacadeAccessor(){
        return 'constcoba';
    }
}