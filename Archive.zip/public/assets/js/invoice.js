/*----simplebar1 JS ----*/
	var invoicelist = document.getElementById('invoicelist')
	new SimpleBar(invoicelist);
	/*-----simplebar1 JS -----*/

	/*----simplebar1 JS ----*/
	var invoicedetailspage = document.getElementById('invoicedetailspage')
	new SimpleBar(invoicedetailspage);
	/*-----simplebar1 JS -----*/