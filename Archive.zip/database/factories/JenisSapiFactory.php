<?php

namespace Database\Factories;

use App\Models\JenisSapi;
use Illuminate\Database\Eloquent\Factories\Factory;

class JenisSapiFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = JenisSapi::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
